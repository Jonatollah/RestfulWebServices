package com.in28minutes.rest.webservices.restfulwebservices.jwt.users;

import java.net.URI;
import java.util.List;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.users.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.JwtInMemoryUserDetailsService;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.RegisterReq;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.resource.MessageResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.in28minutes.rest.webservices.restfulwebservices.todo.Todo;



@CrossOrigin(origins="http://localhost:4200")
@RestController
public class UserJpaResource {

	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	
	@Autowired
	private UserJpaRepository userJpaRepository;
	
	@Autowired
	private JwtInMemoryUserDetailsService detailsService;
	
	@GetMapping("/jpa/users/{username}")
	public User getUser(@PathVariable String username){
		return userJpaRepository.findByUsername(username);
		//return todoService.findById(id);
	}
	
/*
	@GetMapping("/jpa/users")
	public List<User> retrieveAllUsers() {
		return userRepository.findAll();
	}

	@GetMapping("/jpa/users/{id}")
	public EntityModel<User> retrieveUser(@PathVariable int id) {
		Optional<User> user = userJpaRepository.findById(id);

		if (!user.isPresent())
			throw new UserNotFoundException("id-" + id);

		// "all-users", SERVER_PATH + "/users"
		// retrieveAllUsers
		EntityModel<User> resource = EntityModel.of(user.get());//new EntityModel<User>(user.get());

		WebMvcLinkBuilder linkTo = linkTo(methodOn(this.getClass()).retrieveAllUsers());

		resource.add(linkTo.withRel("all-users"));

		// HATEOAS

		return resource;
	}

	@DeleteMapping("/jpa/users/{id}")
	public void deleteUser(@PathVariable int id) {
		userJpaRepository.deleteById(id);
	}

	//
	// input - details of user
	// output - CREATED & Return the created URI

	// HATEOAS
*/ /*
	@PostMapping("/register")
	public ResponseEntity<?> createUser(
			@PathVariable String username, @RequestBody RegisterReq registerReq){
		if (userJpaRepository.existsByUsername(registerReq.getUsername())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Error: Username is already taken!"));
		}
		if (userJpaRepository.existsByEmail(registerReq.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Error: Email is already in use!"));
		}
		
		//Todo createdTodo = todoService.save(todo);
		 
		User user = new User(registerReq.getUsername(),registerReq.getEmail(),encoder.encode(registerReq.getPassword()));
		User createdUser = userJpaRepository.save(user);
		long r =1;
		detailsService.addUser(r,createdUser.getUsername(), createdUser.getPassword(),"1l");
		//Location
		//Get current resource url
		///{id}
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
				.path("/{id}").buildAndExpand(createdUser.getId()).toUri();
		
		return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
	}*/
	/*
	@GetMapping("/jpa/users/{id}/posts")
	public List<Post> retrieveAllUsers(@PathVariable int id) {
		Optional<User> userOptional = userRepository.findById(id);
		
		if(!userOptional.isPresent()) {
			throw new UserNotFoundException("id-" + id);
		}
		
		return userOptional.get().getPosts();
	}*/


}
/*
	@PutMapping("/users/{user}")
	public ResponseEntity<Todo> updateTodo(
			@PathVariable String username,
			@PathVariable long id, @RequestBody Todo todo){
		
		User userUpdated = userService.save(todo);
		
		return new ResponseEntity<Todo>(todo, HttpStatus.OK);
	}
	
	
}*/
