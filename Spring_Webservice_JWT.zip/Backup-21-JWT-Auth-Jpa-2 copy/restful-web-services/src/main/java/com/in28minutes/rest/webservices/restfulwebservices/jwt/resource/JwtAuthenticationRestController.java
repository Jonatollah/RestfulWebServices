package com.in28minutes.rest.webservices.restfulwebservices.jwt.resource;

import java.net.URI;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.in28minutes.rest.webservices.restfulwebservices.jwt.JwtInMemoryUserDetailsService;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.RegisterReq;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.resource.MessageResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.in28minutes.rest.webservices.restfulwebservices.jwt.JwtTokenUtil;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.JwtUserDetails;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.RegisterReq;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.users.User;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.users.UserJpaRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class JwtAuthenticationRestController {
	
	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	@Value("${jwt.http.request.header}")
	private String tokenHeader;

	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private UserJpaRepository userJpaRepository;
	
	@Autowired
	private JwtInMemoryUserDetailsService detailsService;
	
	
	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private UserDetailsService jwtInMemoryUserDetailsService;

	@RequestMapping(value = "${jwt.get.token.uri}", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtTokenRequest authenticationRequest)
			throws AuthenticationException {

		authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());

		final UserDetails userDetails = jwtInMemoryUserDetailsService
				.loadUserByUsername(authenticationRequest.getUsername());

		final String token = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new JwtTokenResponse(token));
	}

	@RequestMapping(value = "${jwt.refresh.token.uri}", method = RequestMethod.GET)
	public ResponseEntity<?> refreshAndGetAuthenticationToken(HttpServletRequest request) {
		String authToken = request.getHeader(tokenHeader);
		final String token = authToken.substring(7);
		String username = jwtTokenUtil.getUsernameFromToken(token);
		JwtUserDetails user = (JwtUserDetails) jwtInMemoryUserDetailsService.loadUserByUsername(username);

		if (jwtTokenUtil.canTokenBeRefreshed(token)) {
			String refreshedToken = jwtTokenUtil.refreshToken(token);
			return ResponseEntity.ok(new JwtTokenResponse(refreshedToken));
		} else {
			return ResponseEntity.badRequest().body(null);
		}
	}
	@PostMapping("auth/register")
	public ResponseEntity<?> createUser(
			@RequestBody RegisterReq registerReq){
		if (userJpaRepository.existsByUsername(registerReq.getUsername())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Error: Username is already taken!"));
		}
		if (userJpaRepository.existsByEmail(registerReq.getEmail())) {
			return ResponseEntity
					.badRequest()
					.body(new MessageResponse("Error: Email is already in use!"));
		}
		
		//Todo createdTodo = todoService.save(todo);
		 
		User user = new User(registerReq.getUsername(),registerReq.getEmail(),encoder.encode(registerReq.getPassword()));
		User createdUser = userJpaRepository.save(user);
		long r =1;
		detailsService.addUser(r,createdUser.getUsername(), createdUser.getPassword(),"1l");
		//Location
		//Get current resource url
		///{id}
		//URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
		//		.path("/{id}").buildAndExpand(createdUser.getId()).toUri();
		
		return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
	}
	
	
	@ExceptionHandler({ AuthenticationException.class })
	public ResponseEntity<String> handleAuthenticationException(AuthenticationException e) {
		return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
	}

	private void authenticate(String username, String password) {
		Objects.requireNonNull(username);
		Objects.requireNonNull(password);

		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} catch (DisabledException e) {
			throw new AuthenticationException("USER_DISABLED", e);
		} catch (BadCredentialsException e) {
			throw new AuthenticationException("INVALID_CREDENTIALS", e);
		}
	}
}
