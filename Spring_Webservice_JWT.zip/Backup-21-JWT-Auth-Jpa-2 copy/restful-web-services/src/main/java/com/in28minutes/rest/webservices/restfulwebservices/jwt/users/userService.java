package com.in28minutes.rest.webservices.restfulwebservices.jwt.users;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import com.in28minutes.rest.webservices.restfulwebservices.jwt.JwtInMemoryUserDetailsService;
import com.in28minutes.rest.webservices.restfulwebservices.jwt.JwtUserDetails;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@Service
public class userService {
	
	private JwtInMemoryUserDetailsService jwtService;
	
	
	
	public void addUser(){
		
				
		jwtService.inMemoryUserList.add(new JwtUserDetails(1L, "in28minutes",
				"$2a$10$3zHzb.Npv1hfZbLEU5qsdOju/tk2je6W6PnNnY.c1ujWPcZh4PL6e", "ROLE_USER_2"));
	}
}
