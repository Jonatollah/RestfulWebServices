package com.in28minutes.rest.webservices.restfulwebservices.jwt.users;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
//import io.swagger.annotations.ApiModel;
//import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(	name = "users", 
uniqueConstraints = { 
	@UniqueConstraint(columnNames = "username"),
	@UniqueConstraint(columnNames = "email") 
})
public class User {


	@Id
	@GeneratedValue
	private Long id;
	
	
	@Size(min=2, message="Name should have at least 2 characters")
	//@ApiModelProperty(notes="Name should have at least 2 characters")
	private String name;
	
	@Past
	//@ApiModelProperty(notes="Name should have at least 2 characters")
	private Date birthdate;
	
	private String username;

	//@OneToMany(mappedBy="user")
	//private List<Post> posts;
	private String password;
	
	private String email;
	private String authority;
	
	protected User() {
		
	}
	
	public User(String username, String email, String password) {
		this.username = username;
		this.email=email;
		this.password = password;

	}

	public String getAuthority() {
		return this.authority;
	}
	
	public Long getId() {
		return id;
	}
	

	public void setId(Long id) {
		this.id = id;
	}
	public String getPassword() {
		return this.password;
	}
	public void setPassword(String password) {
		this.password=password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthdate() {
		return birthdate;
	}
	/*
	public List<Post> getPosts() {
		return posts;
	}
	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}*/

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	@Override
	public String toString() {
		return String.format("User [id=%s, name=%s, birthdate=%s]", id, name, birthdate);
	}
	
	
}
