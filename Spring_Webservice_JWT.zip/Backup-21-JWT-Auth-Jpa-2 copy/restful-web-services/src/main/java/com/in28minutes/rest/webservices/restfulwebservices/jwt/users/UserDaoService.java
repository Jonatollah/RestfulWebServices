package com.in28minutes.rest.webservices.restfulwebservices.jwt.users;

public class UserDaoService {

}
